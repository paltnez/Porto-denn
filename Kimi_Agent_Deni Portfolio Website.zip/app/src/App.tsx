import { useEffect, useState, useRef, useCallback } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { ScrollToPlugin } from 'gsap/ScrollToPlugin';
import './App.css';

// Import sections
import HeroSection from './sections/HeroSection';
import AboutSection from './sections/AboutSection';
import InterestsSection from './sections/InterestsSection';
import GoalsSection from './sections/GoalsSection';
import FunCornerSection from './sections/FunCornerSection';
import ContactSection from './sections/ContactSection';

// Import components
import CustomCursor from './components/CustomCursor';
import Navigation from './components/Navigation';
import FloatingControls from './components/FloatingControls';
import StickyNote from './components/StickyNote';
import AchievementPopup from './components/AchievementPopup';

// Import hooks
import useDarkMode from './hooks/useDarkMode';
import useAudio from './hooks/useAudio';
import useAchievements from './hooks/useAchievements';

gsap.registerPlugin(ScrollTrigger, ScrollToPlugin);

function App() {
  const [isLoaded, setIsLoaded] = useState(false);
  const [showStickyNotes, setShowStickyNotes] = useState(true);
  const { isDark, toggleDark } = useDarkMode();
  const { isPlaying, toggleAudio } = useAudio();
  const { showAchievement, unlockAchievement, clearAchievement } = useAchievements();
  
  const mainRef = useRef<HTMLDivElement>(null);
  const triggersRef = useRef<ScrollTrigger[]>([]);

  // Initialize GSAP and ScrollTrigger
  useEffect(() => {
    // Wait for fonts and initial render
    const timer = setTimeout(() => {
      setIsLoaded(true);
      
      // Refresh ScrollTrigger after content loads
      ScrollTrigger.refresh();
    }, 500);

    return () => {
      clearTimeout(timer);
      // Clean up only this component's triggers on unmount
      triggersRef.current.forEach(trigger => trigger.kill());
    };
  }, []);

  // Global snap for pinned sections
  useEffect(() => {
    if (!isLoaded) return;

    // Small delay to ensure all section triggers are created
    const timer = setTimeout(() => {
      const pinned = ScrollTrigger.getAll()
        .filter(st => st.vars.pin)
        .sort((a, b) => a.start - b.start);
      
      const maxScroll = ScrollTrigger.maxScroll(window);
      
      if (!maxScroll || pinned.length === 0) return;

      const pinnedRanges = pinned.map(st => ({
        start: st.start / maxScroll,
        end: (st.end ?? st.start) / maxScroll,
        center: (st.start + ((st.end ?? st.start) - st.start) * 0.5) / maxScroll,
      }));

      const globalSnap = ScrollTrigger.create({
        snap: {
          snapTo: (value: number) => {
            const inPinned = pinnedRanges.some(r => value >= r.start - 0.02 && value <= r.end + 0.02);
            if (!inPinned) return value;

            const target = pinnedRanges.reduce((closest, r) =>
              Math.abs(r.center - value) < Math.abs(closest - value) ? r.center : closest,
              pinnedRanges[0]?.center ?? 0
            );
            return target;
          },
          duration: { min: 0.15, max: 0.35 },
          delay: 0,
          ease: "power2.out"
        }
      });

      return () => {
        globalSnap.kill();
      };
    }, 100);

    return () => clearTimeout(timer);
  }, [isLoaded]);

  // Scroll to section handler
  const scrollToSection = useCallback((sectionId: string) => {
    const element = document.getElementById(sectionId);
    if (element) {
      gsap.to(window, {
        duration: 1.2,
        scrollTo: { y: element, offsetY: 0 },
        ease: "power3.inOut"
      });
    }
  }, []);

  if (!isLoaded) {
    return (
      <div className="fixed inset-0 flex items-center justify-center bg-paper-warm">
        <div className="text-center">
          <div className="w-16 h-16 border-4 border-scrapbook-blush border-t-transparent rounded-full animate-spin mx-auto mb-4" />
          <p className="handwritten text-2xl text-scrapbook-charcoal">Memuat Jurnal...</p>
        </div>
      </div>
    );
  }

  return (
    <div ref={mainRef} className="relative overflow-x-hidden">
      {/* Custom Cursor */}
      <CustomCursor />
      
      {/* Grain Overlay */}
      <div className="grain-overlay" />
      
      {/* Navigation */}
      <Navigation onNavigate={scrollToSection} />
      
      {/* Floating Controls */}
      <FloatingControls 
        isDark={isDark} 
        onToggleDark={toggleDark}
        isPlaying={isPlaying}
        onToggleAudio={toggleAudio}
      />
      
      {/* Sticky Notes */}
      {showStickyNotes && (
        <>
          <StickyNote 
            color="bg-yellow-200"
            position="left"
            fact="Deni bisa menghabiskan 3 buku dalam seminggu!"
            onClose={() => setShowStickyNotes(false)}
          />
          <StickyNote 
            color="bg-pink-200"
            position="right"
            fact="Makanan favorit Deni adalah bolu!"
            onClose={() => setShowStickyNotes(false)}
          />
        </>
      )}
      
      {/* Achievement Popup */}
      {showAchievement && (
        <AchievementPopup 
          achievement={showAchievement}
          onClose={clearAchievement}
        />
      )}
      
      {/* Main Content */}
      <main className="relative">
        <HeroSection id="hero" />
        <AboutSection id="about" />
        <InterestsSection id="interests" />
        <GoalsSection id="goals" />
        <FunCornerSection 
          id="games" 
          onUnlockAchievement={unlockAchievement}
        />
        <ContactSection id="contact" />
      </main>
    </div>
  );
}

export default App;
