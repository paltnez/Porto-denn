import { useEffect, useRef, useState } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { FaEnvelope, FaPhone, FaInstagram, FaPaperPlane, FaCopy, FaCheck, FaHeart } from 'react-icons/fa';

gsap.registerPlugin(ScrollTrigger);

interface ContactSectionProps {
  id: string;
}

export default function ContactSection({ id }: ContactSectionProps) {
  const sectionRef = useRef<HTMLDivElement>(null);
  const leftCardRef = useRef<HTMLDivElement>(null);
  const rightCardRef = useRef<HTMLDivElement>(null);
  const formRef = useRef<HTMLFormElement>(null);
  
  const [formData, setFormData] = useState({ name: '', email: '', message: '' });
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isSubmitted, setIsSubmitted] = useState(false);
  const [copied, setCopied] = useState(false);

  useEffect(() => {
    const section = sectionRef.current;
    const leftCard = leftCardRef.current;
    const rightCard = rightCardRef.current;

    if (!section || !leftCard || !rightCard) return;

    const ctx = gsap.context(() => {
      // Left card animation
      gsap.fromTo(leftCard,
        { x: -40, opacity: 0 },
        {
          x: 0,
          opacity: 1,
          duration: 0.8,
          scrollTrigger: {
            trigger: leftCard,
            start: 'top 80%',
          }
        }
      );

      // Right card animation
      gsap.fromTo(rightCard,
        { x: 40, opacity: 0 },
        {
          x: 0,
          opacity: 1,
          duration: 0.8,
          delay: 0.2,
          scrollTrigger: {
            trigger: rightCard,
            start: 'top 80%',
          }
        }
      );

      // Polaroid rotation
      const polaroid = leftCard.querySelector('.contact-polaroid');
      if (polaroid) {
        gsap.fromTo(polaroid,
          { rotate: -6, scale: 0.98 },
          {
            rotate: -2,
            scale: 1,
            duration: 0.6,
            delay: 0.4,
            scrollTrigger: {
              trigger: polaroid,
              start: 'top 80%',
            }
          }
        );
      }
    }, section);

    return () => ctx.revert();
  }, []);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);

    // Simulate form submission with envelope animation
    const form = formRef.current;
    if (form) {
      gsap.to(form, {
        scale: 0.95,
        opacity: 0.5,
        duration: 0.3,
        yoyo: true,
        repeat: 1,
      });
    }

    // Simulate API call
    await new Promise(resolve => setTimeout(resolve, 1500));

    setIsSubmitting(false);
    setIsSubmitted(true);
    setFormData({ name: '', email: '', message: '' });

    // Reset after 3 seconds
    setTimeout(() => {
      setIsSubmitted(false);
    }, 3000);
  };

  const handleCopyEmail = () => {
    navigator.clipboard.writeText('yusufgamteng324@gmail.com');
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const openWhatsApp = () => {
    window.open('https://wa.me/685717461863', '_blank');
  };

  const openInstagram = () => {
    window.open('https://www.instagram.com/denn._12', '_blank');
  };

  return (
    <section
      ref={sectionRef}
      id={id}
      className="min-h-screen bg-paper-blue dark:bg-slate-800 py-20 relative overflow-hidden"
    >
      <div className="max-w-6xl mx-auto px-4 md:px-8">
        {/* Heading */}
        <div className="text-center mb-12">
          <h2 className="handwritten text-5xl md:text-6xl text-scrapbook-charcoal dark:text-slate-100 mb-4">
            Let's Connect
          </h2>
          <p className="text-scrapbook-gray dark:text-slate-400 max-w-md mx-auto">
            Have an idea, a question, or just want to say hi? Send a note!
          </p>
        </div>

        {/* Content Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Left Card - Contact Info */}
          <div
            ref={leftCardRef}
            className="paper-card p-6 md:p-8 rounded-[2rem]"
          >
            {/* Polaroid */}
            <div className="contact-polaroid polaroid mb-8 mx-auto w-fit" style={{ transform: 'rotate(-2deg)' }}>
              <img
                src="/images/contact_polaroid.jpg"
                alt="Deni"
                className="w-48 h-56 object-cover"
              />
              <p className="text-center handwritten text-lg text-scrapbook-gray mt-2">
                Let's be friends!
              </p>
            </div>

            {/* Contact Details */}
            <div className="space-y-4">
              {/* WhatsApp */}
              <button
                onClick={openWhatsApp}
                className="w-full flex items-center gap-4 p-4 bg-green-50 dark:bg-green-900/20 rounded-xl hover:bg-green-100 dark:hover:bg-green-900/30 transition-colors group"
              >
                <div className="w-12 h-12 bg-green-500 rounded-full flex items-center justify-center text-white group-hover:scale-110 transition-transform">
                  <FaPhone className="w-5 h-5" />
                </div>
                <div className="text-left">
                  <p className="text-sm text-scrapbook-gray dark:text-slate-400">WhatsApp</p>
                  <p className="font-medium text-scrapbook-charcoal dark:text-slate-200">+62 857-1746-1863</p>
                </div>
              </button>

              {/* Email */}
              <button
                onClick={handleCopyEmail}
                className="w-full flex items-center gap-4 p-4 bg-blue-50 dark:bg-blue-900/20 rounded-xl hover:bg-blue-100 dark:hover:bg-blue-900/30 transition-colors group"
              >
                <div className="w-12 h-12 bg-blue-500 rounded-full flex items-center justify-center text-white group-hover:scale-110 transition-transform">
                  {copied ? <FaCheck className="w-5 h-5" /> : <FaEnvelope className="w-5 h-5" />}
                </div>
                <div className="text-left flex-1">
                  <p className="text-sm text-scrapbook-gray dark:text-slate-400">Email</p>
                  <p className="font-medium text-scrapbook-charcoal dark:text-slate-200 text-sm truncate">
                    yusufgamteng324@gmail.com
                  </p>
                </div>
                <FaCopy className={`w-4 h-4 text-scrapbook-gray transition-opacity ${copied ? 'opacity-0' : 'opacity-100'}`} />
              </button>

              {/* Instagram */}
              <button
                onClick={openInstagram}
                className="w-full flex items-center gap-4 p-4 bg-pink-50 dark:bg-pink-900/20 rounded-xl hover:bg-pink-100 dark:hover:bg-pink-900/30 transition-colors group"
              >
                <div className="w-12 h-12 bg-gradient-to-br from-purple-500 to-pink-500 rounded-full flex items-center justify-center text-white group-hover:scale-110 transition-transform">
                  <FaInstagram className="w-5 h-5" />
                </div>
                <div className="text-left">
                  <p className="text-sm text-scrapbook-gray dark:text-slate-400">Instagram</p>
                  <p className="font-medium text-scrapbook-charcoal dark:text-slate-200">@denn._12</p>
                </div>
              </button>
            </div>
          </div>

          {/* Right Card - Contact Form */}
          <div
            ref={rightCardRef}
            className="paper-card p-6 md:p-8 rounded-[2rem] relative"
          >
            {/* Washi tape */}
            <div className="absolute -top-3 right-8 w-24 h-6 bg-scrapbook-blush/80 -rotate-1" />

            <h3 className="handwritten text-3xl text-scrapbook-charcoal dark:text-slate-100 mb-6">
              Send a Message
            </h3>

            {isSubmitted ? (
              <div className="flex flex-col items-center justify-center py-12 animate-pop-in">
                <div className="w-20 h-20 bg-green-100 dark:bg-green-900/30 rounded-full flex items-center justify-center mb-4">
                  <FaPaperPlane className="w-8 h-8 text-green-500" />
                </div>
                <h4 className="handwritten text-2xl text-scrapbook-charcoal dark:text-slate-100 mb-2">
                  Message Sent!
                </h4>
                <p className="text-scrapbook-gray dark:text-slate-400 text-center">
                  Thanks for reaching out. I'll get back to you soon!
                </p>
              </div>
            ) : (
              <form ref={formRef} onSubmit={handleSubmit} className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-scrapbook-charcoal dark:text-slate-300 mb-2">
                    Your Name
                  </label>
                  <input
                    type="text"
                    value={formData.name}
                    onChange={(e) => setFormData(prev => ({ ...prev, name: e.target.value }))}
                    required
                    className="input-scrapbook"
                    placeholder="John Doe"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-scrapbook-charcoal dark:text-slate-300 mb-2">
                    Your Email
                  </label>
                  <input
                    type="email"
                    value={formData.email}
                    onChange={(e) => setFormData(prev => ({ ...prev, email: e.target.value }))}
                    required
                    className="input-scrapbook"
                    placeholder="john@example.com"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-scrapbook-charcoal dark:text-slate-300 mb-2">
                    Message
                  </label>
                  <textarea
                    value={formData.message}
                    onChange={(e) => setFormData(prev => ({ ...prev, message: e.target.value }))}
                    required
                    rows={4}
                    className="input-scrapbook resize-none"
                    placeholder="Hello Deni, I'd like to..."
                  />
                </div>

                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="w-full btn-scrapbook flex items-center justify-center gap-2 disabled:opacity-70"
                >
                  {isSubmitting ? (
                    <>
                      <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin" />
                      <span>Sending...</span>
                    </>
                  ) : (
                    <>
                      <FaPaperPlane className="w-4 h-4" />
                      <span>Send Message</span>
                    </>
                  )}
                </button>
              </form>
            )}
          </div>
        </div>

        {/* Footer */}
        <div className="mt-16 text-center">
          <p className="text-sm text-scrapbook-gray dark:text-slate-500 flex items-center justify-center gap-2">
            Made with <FaHeart className="w-4 h-4 text-scrapbook-blush" /> by Deni Aryadi
          </p>
          <p className="text-xs text-scrapbook-gray/60 dark:text-slate-600 mt-2">
            © 2024 Deni's Digital Journal. Built with curiosity (and a little caffeine).
          </p>
        </div>
      </div>
    </section>
  );
}
