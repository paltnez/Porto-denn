import { useEffect, useRef } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { FaArrowDown, FaHeart, FaStar } from 'react-icons/fa';

gsap.registerPlugin(ScrollTrigger);

interface HeroSectionProps {
  id: string;
}

export default function HeroSection({ id }: HeroSectionProps) {
  const sectionRef = useRef<HTMLDivElement>(null);
  const cardRef = useRef<HTMLDivElement>(null);
  const polaroidRef = useRef<HTMLDivElement>(null);
  const titleRef = useRef<HTMLHeadingElement>(null);
  const subtitleRef = useRef<HTMLParagraphElement>(null);
  const ctaRef = useRef<HTMLButtonElement>(null);
  const stickersRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const section = sectionRef.current;
    const card = cardRef.current;
    const polaroid = polaroidRef.current;
    const title = titleRef.current;
    const subtitle = subtitleRef.current;
    const cta = ctaRef.current;
    const stickers = stickersRef.current;

    if (!section || !card || !polaroid || !title || !subtitle || !cta || !stickers) return;

    const ctx = gsap.context(() => {
      // Initial load animation
      const loadTl = gsap.timeline({ delay: 0.3 });

      // Card entrance
      loadTl.fromTo(card,
        { opacity: 0, y: 40, rotate: -1 },
        { opacity: 1, y: 0, rotate: 0, duration: 1, ease: 'power3.out' }
      );

      // Polaroid entrance
      loadTl.fromTo(polaroid,
        { opacity: 0, x: -60, rotate: -6 },
        { opacity: 1, x: 0, rotate: -2, duration: 0.9, ease: 'back.out(1.6)' },
        '-=0.85'
      );

      // Title character animation
      const chars = title.querySelectorAll('.char');
      loadTl.fromTo(chars,
        { opacity: 0, y: 30, rotate: -8 },
        { opacity: 1, y: 0, rotate: 0, duration: 0.6, stagger: 0.03, ease: 'power3.out' },
        '-=0.6'
      );

      // Subtitle entrance
      loadTl.fromTo(subtitle,
        { opacity: 0, y: 16 },
        { opacity: 1, y: 0, duration: 0.6, ease: 'power2.out' },
        '-=0.3'
      );

      // CTA entrance
      loadTl.fromTo(cta,
        { opacity: 0, scale: 0.85 },
        { opacity: 1, scale: 1, duration: 0.5, ease: 'back.out(1.7)' },
        '-=0.2'
      );

      // Stickers pop-in
      const stickerElements = stickers.querySelectorAll('.sticker');
      loadTl.fromTo(stickerElements,
        { opacity: 0, scale: 0 },
        { opacity: 1, scale: 1, duration: 0.5, stagger: 0.08, ease: 'back.out(1.8)' },
        '-=0.4'
      );

      // Scroll-driven exit animation
      const scrollTl = gsap.timeline({
        scrollTrigger: {
          trigger: section,
          start: 'top top',
          end: '+=130%',
          pin: true,
          scrub: 0.6,
          onLeaveBack: () => {
            // Reset all elements when scrolling back to top
            gsap.set([card, polaroid, title, subtitle, cta], { opacity: 1, x: 0, y: 0, rotate: 0 });
            gsap.set(stickerElements, { opacity: 1, x: 0, y: 0 });
          }
        }
      });

      // Exit animations (70% - 100%)
      scrollTl.fromTo(card,
        { x: 0, rotate: 0, opacity: 1 },
        { x: '-55vw', rotate: -4, opacity: 0, ease: 'power2.in' },
        0.7
      );

      scrollTl.fromTo(polaroid,
        { x: 0, y: 0, rotate: -2, opacity: 1 },
        { x: '-30vw', y: '10vh', rotate: -8, opacity: 0, ease: 'power2.in' },
        0.7
      );

      scrollTl.fromTo([title, subtitle],
        { x: 0, opacity: 1 },
        { x: '18vw', opacity: 0, ease: 'power2.in' },
        0.7
      );

      scrollTl.fromTo(cta,
        { x: 0, opacity: 1 },
        { x: '18vw', opacity: 0, ease: 'power2.in' },
        0.75
      );

      // Stickers drift outward
      stickerElements.forEach((sticker, i) => {
        const direction = i % 2 === 0 ? 1 : -1;
        scrollTl.fromTo(sticker,
          { x: 0, y: 0, opacity: 1 },
          { x: `${direction * (15 + i * 3)}vw`, y: `${(i % 3 - 1) * 10}vh`, opacity: 0, ease: 'power2.in' },
          0.7
        );
      });

    }, section);

    return () => ctx.revert();
  }, []);

  const scrollToAbout = () => {
    gsap.to(window, {
      duration: 1.2,
      scrollTo: { y: '#about', offsetY: 0 },
      ease: 'power3.inOut'
    });
  };

  // Split title into characters
  const titleText = "Jurnal Deni";
  const titleChars = titleText.split('').map((char, i) => (
    <span key={i} className="char inline-block" style={{ display: char === ' ' ? 'inline' : 'inline-block' }}>
      {char === ' ' ? '\u00A0' : char}
    </span>
  ));

  return (
    <section
      ref={sectionRef}
      id={id}
      className="section-pinned bg-paper-warm dark:bg-slate-900 flex items-center justify-center relative overflow-hidden"
    >
      {/* Background Pattern */}
      <div className="absolute inset-0 opacity-5">
        <div className="absolute top-10 left-10 w-32 h-32 border-2 border-scrapbook-charcoal rounded-full" />
        <div className="absolute bottom-20 right-20 w-24 h-24 border-2 border-scrapbook-charcoal rotate-12" />
        <div className="absolute top-1/3 right-1/4 w-16 h-16 border-2 border-scrapbook-charcoal -rotate-6" />
      </div>

      {/* Main Card */}
      <div
        ref={cardRef}
        className="relative w-[90vw] max-w-5xl h-[80vh] max-h-[700px] paper-card rounded-[2rem] overflow-visible"
      >
        {/* Washi Tape */}
        <div className="absolute -top-3 left-1/2 -translate-x-1/2 w-48 h-8 bg-scrapbook-dusty/80 rotate-1" />

        {/* Content Grid */}
        <div className="h-full grid grid-cols-1 md:grid-cols-2 gap-8 p-8 md:p-12">
          {/* Left: Polaroid */}
          <div className="flex items-center justify-center">
            <div
              ref={polaroidRef}
              className="polaroid transform -rotate-2 hover:rotate-0 transition-transform duration-300"
            >
              <img
                src="/images/hero_denifoto.jpg"
                alt="Deni"
                className="w-48 h-56 md:w-56 md:h-64 object-cover"
              />
              <p className="absolute bottom-3 left-0 right-0 text-center handwritten text-lg text-scrapbook-gray">
                Deni Aryadi
              </p>
            </div>
          </div>

          {/* Right: Text Content */}
          <div className="flex flex-col justify-center items-start">
            <h1
              ref={titleRef}
              className="handwritten text-5xl md:text-7xl lg:text-8xl text-scrapbook-charcoal dark:text-slate-100 mb-4 leading-tight"
            >
              {titleChars}
            </h1>

            <p
              ref={subtitleRef}
              className="text-lg md:text-xl text-scrapbook-gray dark:text-slate-400 mb-2 leading-relaxed"
            >
              Future Digital Marketer & Data Enthusiast
            </p>

            <p className="text-sm text-scrapbook-gray/70 dark:text-slate-500 mb-8">
              Kelas 11 • SMAN 55 Jakarta
            </p>

            <button
              ref={ctaRef}
              onClick={scrollToAbout}
              className="btn-scrapbook flex items-center gap-2 group"
            >
              <span>Buka Jurnal Saya</span>
              <FaArrowDown className="w-4 h-4 group-hover:translate-y-1 transition-transform" />
            </button>
          </div>
        </div>
      </div>

      {/* Decorative Stickers */}
      <div ref={stickersRef} className="absolute inset-0 pointer-events-none">
        {/* Heart sticker */}
        <div className="sticker absolute top-[10%] left-[5%] w-12 h-12 bg-scrapbook-blush rounded-full flex items-center justify-center text-white animate-float">
          <FaHeart className="w-5 h-5" />
        </div>

        {/* Star sticker */}
        <div className="sticker absolute top-[12%] right-[8%] w-14 h-14 bg-yellow-300 rounded-full flex items-center justify-center text-white animate-float" style={{ animationDelay: '0.5s' }}>
          <FaStar className="w-6 h-6" />
        </div>

        {/* Circle sticker */}
        <div className="sticker absolute bottom-[15%] left-[8%] w-10 h-10 bg-scrapbook-dusty rounded-full animate-float" style={{ animationDelay: '1s' }} />

        {/* Arrow sticker */}
        <div className="sticker absolute bottom-[18%] right-[5%] w-16 h-8 bg-scrapbook-sage rounded-lg flex items-center justify-center text-white animate-float" style={{ animationDelay: '1.5s' }}>
          <span className="text-xs font-bold">→</span>
        </div>

        {/* Small decorative dots */}
        <div className="sticker absolute top-[30%] right-[15%] w-4 h-4 bg-scrapbook-peach rounded-full animate-bounce-soft" />
        <div className="sticker absolute bottom-[30%] left-[15%] w-3 h-3 bg-scrapbook-lavender rounded-full animate-bounce-soft" style={{ animationDelay: '0.7s' }} />
      </div>

      {/* Scroll indicator */}
      <div className="absolute bottom-8 left-1/2 -translate-x-1/2 flex flex-col items-center gap-2 text-scrapbook-gray/50">
        <span className="text-xs uppercase tracking-widest">Gulir untuk menjelajah</span>
        <div className="w-6 h-10 border-2 border-current rounded-full flex justify-center pt-2">
          <div className="w-1 h-2 bg-current rounded-full animate-bounce" />
        </div>
      </div>
    </section>
  );
}
