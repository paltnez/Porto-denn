import { useEffect, useRef } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { FaBook, FaUtensils, FaChartLine, FaHeart, FaStar } from 'react-icons/fa';

gsap.registerPlugin(ScrollTrigger);

interface AboutSectionProps {
  id: string;
}

const funFacts = [
  { icon: FaBook, text: 'Pembaca & penggemar film' },
  { icon: FaUtensils, text: 'Hobi memasak (eksperimen akhir pekan)' },
  { icon: FaChartLine, text: 'Aspiring data enthusiast' },
];

export default function AboutSection({ id }: AboutSectionProps) {
  const sectionRef = useRef<HTMLDivElement>(null);
  const leftCardRef = useRef<HTMLDivElement>(null);
  const rightCardRef = useRef<HTMLDivElement>(null);
  const stickersRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const section = sectionRef.current;
    const leftCard = leftCardRef.current;
    const rightCard = rightCardRef.current;
    const stickers = stickersRef.current;

    if (!section || !leftCard || !rightCard || !stickers) return;

    const ctx = gsap.context(() => {
      const scrollTl = gsap.timeline({
        scrollTrigger: {
          trigger: section,
          start: 'top top',
          end: '+=130%',
          pin: true,
          scrub: 0.6,
        }
      });

      // Left card entrance (0% - 30%)
      scrollTl.fromTo(leftCard,
        { x: '-60vw', rotate: -6, opacity: 0 },
        { x: 0, rotate: -1.5, opacity: 1, ease: 'none' },
        0
      );

      // Photos stagger entrance
      const photos = leftCard.querySelectorAll('.polaroid-photo');
      photos.forEach((photo, i) => {
        scrollTl.fromTo(photo,
          { y: `${40 + i * 10}vh`, rotate: -10 + i * 4, opacity: 0 },
          { y: 0, rotate: -3 + i * 2, opacity: 1, ease: 'none' },
          0.05 + i * 0.03
        );
      });

      // Right card entrance (0% - 30%)
      scrollTl.fromTo(rightCard,
        { x: '60vw', rotate: 6, opacity: 0 },
        { x: 0, rotate: 1, opacity: 1, ease: 'none' },
        0
      );

      // Text elements entrance
      const heading = rightCard.querySelector('.section-heading');
      const paragraphs = rightCard.querySelectorAll('.about-text');
      const listItems = rightCard.querySelectorAll('.fact-item');

      scrollTl.fromTo(heading,
        { y: 24, opacity: 0 },
        { y: 0, opacity: 1, ease: 'none' },
        0.1
      );

      paragraphs.forEach((p, i) => {
        scrollTl.fromTo(p,
          { y: 18, opacity: 0 },
          { y: 0, opacity: 1, ease: 'none' },
          0.15 + i * 0.05
        );
      });

      listItems.forEach((item, i) => {
        scrollTl.fromTo(item,
          { x: 20, opacity: 0 },
          { x: 0, opacity: 1, ease: 'none' },
          0.25 + i * 0.04
        );
      });

      // Stickers entrance
      const stickerElements = stickers.querySelectorAll('.sticker');
      stickerElements.forEach((sticker, i) => {
        scrollTl.fromTo(sticker,
          { scale: 0, opacity: 0 },
          { scale: 1, opacity: 1, ease: 'back.out(1.8)' },
          0.1 + i * 0.05
        );
      });

      // Exit animations (70% - 100%)
      scrollTl.fromTo(leftCard,
        { x: 0, opacity: 1 },
        { x: '-40vw', opacity: 0, ease: 'power2.in' },
        0.7
      );

      scrollTl.fromTo(photos,
        { y: 0, opacity: 1 },
        { y: '-18vh', opacity: 0, ease: 'power2.in', stagger: 0.02 },
        0.7
      );

      scrollTl.fromTo(rightCard,
        { x: 0, opacity: 1 },
        { x: '40vw', opacity: 0, ease: 'power2.in' },
        0.7
      );

      scrollTl.fromTo(stickerElements,
        { opacity: 1 },
        { opacity: 0, ease: 'power2.in', stagger: 0.02 },
        0.75
      );

    }, section);

    return () => ctx.revert();
  }, []);

  return (
    <section
      ref={sectionRef}
      id={id}
      className="section-pinned bg-paper-warm dark:bg-slate-900 flex items-center justify-center relative overflow-hidden"
    >
      <div className="w-full max-w-7xl mx-auto px-4 md:px-8 grid grid-cols-1 lg:grid-cols-2 gap-8 items-center">
        {/* Left Card - Photo Collage */}
        <div
          ref={leftCardRef}
          className="paper-card p-6 md:p-8 rounded-[2rem] relative"
          style={{ transform: 'rotate(-1.5deg)' }}
        >
          <h3 className="handwritten text-2xl text-scrapbook-charcoal dark:text-slate-100 mb-6 text-center">
            Momen-Momenku
          </h3>

          {/* Photo Stack */}
          <div className="relative h-[350px] md:h-[400px]">
            {/* Photo 1 */}
            <div
              className="polaroid-photo absolute top-0 left-0 w-40 md:w-48 polaroid"
              style={{ transform: 'rotate(-3deg)' }}
            >
              <img
                src="/images/about_photo_01.jpg"
                alt="Membaca"
                className="w-full h-44 md:h-52 object-cover"
              />
              <p className="text-center handwritten text-sm text-scrapbook-gray mt-2">Waktu membaca</p>
            </div>

            {/* Photo 2 */}
            <div
              className="polaroid-photo absolute top-16 left-20 md:left-28 w-40 md:w-48 polaroid"
              style={{ transform: 'rotate(2deg)' }}
            >
              <img
                src="/images/about_photo_02.jpg"
                alt="Memasak"
                className="w-full h-44 md:h-52 object-cover"
              />
              <p className="text-center handwritten text-sm text-scrapbook-gray mt-2">Memasak</p>
            </div>

            {/* Photo 3 */}
            <div
              className="polaroid-photo absolute top-32 left-10 md:left-16 w-40 md:w-48 polaroid"
              style={{ transform: 'rotate(-1deg)' }}
            >
              <img
                src="/images/about_photo_03.jpg"
                alt="Nonton Film"
                className="w-full h-44 md:h-52 object-cover"
              />
              <p className="text-center handwritten text-sm text-scrapbook-gray mt-2">Movie night</p>
            </div>
          </div>
        </div>

        {/* Right Card - About Text */}
        <div
          ref={rightCardRef}
          className="paper-card p-6 md:p-10 rounded-[2rem] relative"
          style={{ transform: 'rotate(1deg)' }}
        >
          {/* Washi tape */}
          <div className="absolute -top-3 right-8 w-24 h-6 bg-scrapbook-sage/80 -rotate-2" />

          <h2 className="section-heading handwritten text-4xl md:text-5xl text-scrapbook-charcoal dark:text-slate-100 mb-6 doodle-line inline-block">
            Tentang Saya
          </h2>

          <p className="about-text text-base md:text-lg text-scrapbook-charcoal dark:text-slate-300 mb-4 leading-relaxed">
            Halo, saya <span className="font-semibold text-scrapbook-blush">Deni Aryadi</span> — seorang siswa yang menyukai cerita, rasa, dan data yang baik.
          </p>

          <p className="about-text text-base text-scrapbook-gray dark:text-slate-400 mb-4 leading-relaxed">
            Saya penasaran tentang bagaimana orang mengambil keputusan, dan saya senang mengubah ide-ide yang berantakan menjadi rencana yang jelas. Saat ini sedang mengeksplorasi digital marketing, data science, dan menulis kreatif.
          </p>

          <p className="about-text text-base text-scrapbook-gray dark:text-slate-400 mb-6 leading-relaxed">
            Sebagai siswa di SMAN 55 Jakarta, saya selalu bersemangat untuk mempelajari hal-hal baru dan menantang diri sendiri untuk berkembang baik secara akademis maupun pribadi.
          </p>

          {/* Fun Facts */}
          <div className="space-y-3">
            <p className="text-sm font-medium text-scrapbook-gray dark:text-slate-500 uppercase tracking-wider">
              Fakta Cepat
            </p>
            {funFacts.map((fact, i) => (
              <div
                key={i}
                className="fact-item flex items-center gap-3 p-3 bg-paper-cream dark:bg-slate-800 rounded-xl"
              >
                <div className="w-10 h-10 bg-scrapbook-blush/20 rounded-full flex items-center justify-center">
                  <fact.icon className="w-5 h-5 text-scrapbook-blush" />
                </div>
                <span className="text-sm text-scrapbook-charcoal dark:text-slate-300">{fact.text}</span>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Decorative Stickers */}
      <div ref={stickersRef} className="absolute inset-0 pointer-events-none">
        <div className="sticker absolute top-[15%] right-[10%] w-10 h-10 bg-scrapbook-blush rounded-full flex items-center justify-center text-white animate-float">
          <FaHeart className="w-4 h-4" />
        </div>
        <div className="sticker absolute bottom-[20%] left-[5%] w-12 h-12 bg-yellow-300 rounded-full flex items-center justify-center text-white animate-float" style={{ animationDelay: '0.5s' }}>
          <FaStar className="w-5 h-5" />
        </div>
      </div>
    </section>
  );
}
