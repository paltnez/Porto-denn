import { useEffect, useRef, useState } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { FaBookOpen, FaUtensils, FaFilm, FaHeart, FaStar, FaArrowRight } from 'react-icons/fa';

gsap.registerPlugin(ScrollTrigger);

interface InterestsSectionProps {
  id: string;
}

const interests = [
  {
    id: 'reading',
    title: 'Membaca',
    icon: FaBookOpen,
    image: '/images/interest_reading.jpg',
    shortDesc: 'Fiksi, pengembangan diri, dan sesekali misteri.',
    fullDesc: 'Saya suka tenggelam dalam buku! Dari novel fantasi yang membawa saya ke dunia ajaib, hingga buku pengembangan diri yang membantu saya tumbuh. Genre favorit saya adalah misteri, psikologi, dan fiksi remaja. Saya bisa dengan mudah menyelesaikan sebuah buku dalam 2-3 hari jika saya sangat menyukainya!',
    color: 'bg-scrapbook-dusty',
    rotate: -2,
  },
  {
    id: 'cooking',
    title: 'Memasak',
    icon: FaUtensils,
    image: '/images/interest_cooking.jpg',
    shortDesc: 'Resep keluarga yang teruji + eksperimen akhir pekan.',
    fullDesc: 'Memasak adalah outlet kreatif saya! Saya senang bereksperimen dengan resep baru di akhir pekan dan menyempurnakan favorit keluarga. Masakan andalan saya adalah Nasi Goreng Spesial dengan campuran rem rahasia. Saya percaya makanan yang enak menyatukan orang-orang.',
    color: 'bg-scrapbook-sage',
    rotate: 0,
  },
  {
    id: 'movies',
    title: 'Nonton Film',
    icon: FaFilm,
    image: '/images/interest_movies.jpg',
    shortDesc: 'Dari cerita slice-of-life hingga thriller plot twist.',
    fullDesc: 'Malam film adalah cara favorit saya untuk bersantai! Saya menikmati segalanya mulai dari cerita slice-of-life yang mengharukan hingga thriller yang membingungkan dengan plot twist. Beberapa favorit saya termasuk film Studio Ghibli, film Marvel, dan drama Korea.',
    color: 'bg-scrapbook-blush',
    rotate: 2,
  },
];

export default function InterestsSection({ id }: InterestsSectionProps) {
  const sectionRef = useRef<HTMLDivElement>(null);
  const headingRef = useRef<HTMLHeadingElement>(null);
  const cardsRef = useRef<HTMLDivElement>(null);
  const stickersRef = useRef<HTMLDivElement>(null);
  const [flippedCard, setFlippedCard] = useState<string | null>(null);

  useEffect(() => {
    const section = sectionRef.current;
    const heading = headingRef.current;
    const cards = cardsRef.current;
    const stickers = stickersRef.current;

    if (!section || !heading || !cards || !stickers) return;

    const ctx = gsap.context(() => {
      const scrollTl = gsap.timeline({
        scrollTrigger: {
          trigger: section,
          start: 'top top',
          end: '+=140%',
          pin: true,
          scrub: 0.6,
        }
      });

      // Heading entrance (0% - 20%)
      scrollTl.fromTo(heading,
        { y: '-12vh', opacity: 0 },
        { y: 0, opacity: 1, ease: 'none' },
        0
      );

      // Cards staggered entrance (5% - 30%)
      const cardElements = cards.querySelectorAll('.interest-card');
      cardElements.forEach((card, i) => {
        const startY = 80 + i * 10;
        const startRotate = [-10, 0, 10][i];
        const endRotate = [-2, 0, 2][i];

        scrollTl.fromTo(card,
          { y: `${startY}vh`, rotate: startRotate, opacity: 0 },
          { y: 0, rotate: endRotate, opacity: 1, ease: 'none' },
          0.05 + i * 0.05
        );

        // Image inside card
        const img = card.querySelector('img');
        if (img) {
          scrollTl.fromTo(img,
            { scale: 1.06, opacity: 0 },
            { scale: 1, opacity: 1, ease: 'none' },
            0.1 + i * 0.05
          );
        }
      });

      // Stickers entrance
      const stickerElements = stickers.querySelectorAll('.sticker');
      stickerElements.forEach((sticker, i) => {
        scrollTl.fromTo(sticker,
          { scale: 0, opacity: 0 },
          { scale: 1, opacity: 1, ease: 'back.out(1.8)' },
          0.1 + i * 0.04
        );
      });

      // Exit animations (70% - 100%)
      scrollTl.fromTo(heading,
        { y: 0, opacity: 1 },
        { y: '-10vh', opacity: 0, ease: 'power2.in' },
        0.7
      );

      cardElements.forEach((card, i) => {
        scrollTl.fromTo(card,
          { y: 0, opacity: 1 },
          { y: '-40vh', opacity: 0, ease: 'power2.in' },
          0.7 + i * 0.02
        );
      });

      scrollTl.fromTo(stickerElements,
        { opacity: 1 },
        { opacity: 0, ease: 'power2.in', stagger: 0.02 },
        0.75
      );

    }, section);

    return () => ctx.revert();
  }, []);

  const handleCardClick = (id: string) => {
    setFlippedCard(flippedCard === id ? null : id);
  };

  return (
    <section
      ref={sectionRef}
      id={id}
      className="section-pinned bg-paper-warm dark:bg-slate-900 flex flex-col items-center justify-center relative overflow-hidden"
    >
      {/* Heading */}
      <h2
        ref={headingRef}
        className="handwritten text-5xl md:text-6xl text-scrapbook-charcoal dark:text-slate-100 mb-12 text-center"
      >
        Hobiku
      </h2>

      {/* Cards Grid */}
      <div
        ref={cardsRef}
        className="w-full max-w-6xl mx-auto px-4 grid grid-cols-1 md:grid-cols-3 gap-6 md:gap-8"
      >
        {interests.map((interest) => (
          <div
            key={interest.id}
            className="interest-card relative"
            style={{ transform: `rotate(${interest.rotate}deg)` }}
          >
            <div
              className={`paper-card rounded-[1.5rem] overflow-hidden cursor-pointer transition-all duration-500 ${
                flippedCard === interest.id ? 'h-auto' : ''
              }`}
              onClick={() => handleCardClick(interest.id)}
            >
              {/* Front */}
              <div className="relative">
                {/* Image */}
                <div className="relative h-48 md:h-56 overflow-hidden">
                  <img
                    src={interest.image}
                    alt={interest.title}
                    className="w-full h-full object-cover transition-transform duration-500 hover:scale-105"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/30 to-transparent" />
                </div>

                {/* Content */}
                <div className="p-5">
                  <div className="flex items-center gap-3 mb-3">
                    <div className={`w-10 h-10 ${interest.color} rounded-full flex items-center justify-center text-white`}>
                      <interest.icon className="w-5 h-5" />
                    </div>
                    <h3 className="handwritten text-2xl text-scrapbook-charcoal dark:text-slate-100">
                      {interest.title}
                    </h3>
                  </div>

                  <p className="text-sm text-scrapbook-gray dark:text-slate-400 mb-3">
                    {interest.shortDesc}
                  </p>

                  <button className="flex items-center gap-2 text-sm text-scrapbook-blush hover:text-scrapbook-charcoal dark:hover:text-slate-200 transition-colors group">
                    <span>Pelajari lebih lanjut</span>
                    <FaArrowRight className="w-3 h-3 group-hover:translate-x-1 transition-transform" />
                  </button>
                </div>
              </div>

              {/* Expanded Content */}
              {flippedCard === interest.id && (
                <div className="px-5 pb-5 animate-slide-up">
                  <div className="pt-3 border-t border-scrapbook-sand/30 dark:border-slate-700">
                    <p className="text-sm text-scrapbook-charcoal dark:text-slate-300 leading-relaxed">
                      {interest.fullDesc}
                    </p>
                  </div>
                </div>
              )}
            </div>
          </div>
        ))}
      </div>

      {/* Decorative Stickers */}
      <div ref={stickersRef} className="absolute inset-0 pointer-events-none">
        <div className="sticker absolute top-[20%] left-[5%] w-10 h-10 bg-scrapbook-blush rounded-full flex items-center justify-center text-white animate-float">
          <FaHeart className="w-4 h-4" />
        </div>
        <div className="sticker absolute top-[25%] right-[8%] w-12 h-12 bg-yellow-300 rounded-full flex items-center justify-center text-white animate-float" style={{ animationDelay: '0.5s' }}>
          <FaStar className="w-5 h-5" />
        </div>
        <div className="sticker absolute bottom-[15%] left-[10%] w-8 h-8 bg-scrapbook-dusty rounded-full animate-float" style={{ animationDelay: '1s' }} />
        <div className="sticker absolute bottom-[20%] right-[5%] w-6 h-6 bg-scrapbook-peach rounded-full animate-float" style={{ animationDelay: '1.5s' }} />
      </div>
    </section>
  );
}
