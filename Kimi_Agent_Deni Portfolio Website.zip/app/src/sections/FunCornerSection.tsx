import { useEffect, useRef, useState, useCallback } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { FaGamepad, FaPuzzlePiece, FaImage, FaCalculator, FaTrophy, FaArrowRight } from 'react-icons/fa';
import confetti from 'canvas-confetti';

gsap.registerPlugin(ScrollTrigger);

interface FunCornerSectionProps {
  id: string;
  onUnlockAchievement: (id: string) => void;
}

// Word Puzzle Game
const WORD_PUZZLE_WORDS = [
  { word: 'MARKETING', hint: 'Promoting products or services' },
  { word: 'DATA', hint: 'Facts and statistics collected for analysis' },
  { word: 'ANALYSIS', hint: 'Detailed examination of data' },
  { word: 'CREATIVE', hint: 'Relating to imagination and original ideas' },
  { word: 'STRATEGY', hint: 'Plan of action to achieve goals' },
];

// Picture Quiz Game
const PICTURE_QUIZ_QUESTIONS = [
  { answer: 'LAPTOP', emoji: '💻', hint: 'Portable computer' },
  { answer: 'BOOK', emoji: '📚', hint: 'Source of knowledge' },
  { answer: 'PHONE', emoji: '📱', hint: 'Mobile device' },
  { answer: 'SCHOOL', emoji: '🏫', hint: 'Place of learning' },
  { answer: 'CHART', emoji: '📊', hint: 'Data visualization' },
];

// Math Challenge Game
const MATH_QUESTIONS = [
  { question: '2x + 5 = 15', answer: 5 },
  { question: '3(x - 2) = 12', answer: 6 },
  { question: 'x² = 64', answer: 8 },
  { question: '5x - 3 = 2x + 9', answer: 4 },
  { question: '(x + 4)² = 64', answer: 4 },
];

export default function FunCornerSection({ id, onUnlockAchievement }: FunCornerSectionProps) {
  const sectionRef = useRef<HTMLDivElement>(null);
  const headingRef = useRef<HTMLDivElement>(null);
  const gamesRef = useRef<HTMLDivElement>(null);
  const leaderboardRef = useRef<HTMLDivElement>(null);

  // Game states
  const [activeGame, setActiveGame] = useState<string | null>(null);
  const [wordPuzzle, setWordPuzzle] = useState({ currentWord: 0, letters: [] as string[], shuffled: [] as string[], solved: [] as boolean[] });
  const [pictureQuiz, setPictureQuiz] = useState({ currentQ: 0, score: 0, answered: false });
  const [mathChallenge, setMathChallenge] = useState({ currentQ: 0, score: 0, streak: 0, answer: '' });
  const [leaderboard, setLeaderboard] = useState<{ name: string; score: number; game: string }[]>([]);

  // Initialize scroll animations
  useEffect(() => {
    const section = sectionRef.current;
    const heading = headingRef.current;
    const games = gamesRef.current;
    const leaderboardEl = leaderboardRef.current;

    if (!section || !heading || !games || !leaderboardEl) return;

    const ctx = gsap.context(() => {
      // Heading animation
      gsap.fromTo(heading,
        { y: 24, opacity: 0 },
        {
          y: 0,
          opacity: 1,
          duration: 0.8,
          scrollTrigger: {
            trigger: heading,
            start: 'top 80%',
          }
        }
      );

      // Games cards animation
      const gameCards = games.querySelectorAll('.game-card');
      gameCards.forEach((card, i) => {
        gsap.fromTo(card,
          { y: 60, rotate: -2, opacity: 0 },
          {
            y: 0,
            rotate: 0,
            opacity: 1,
            duration: 0.6,
            delay: i * 0.1,
            scrollTrigger: {
              trigger: card,
              start: 'top 85%',
            }
          }
        );
      });

      // Leaderboard animation
      gsap.fromTo(leaderboardEl,
        { y: 40, scale: 0.98, opacity: 0 },
        {
          y: 0,
          scale: 1,
          opacity: 1,
          duration: 0.6,
          scrollTrigger: {
            trigger: leaderboardEl,
            start: 'top 85%',
          }
        }
      );
    }, section);

    return () => ctx.revert();
  }, []);

  // Initialize Word Puzzle
  const initWordPuzzle = useCallback(() => {
    const word = WORD_PUZZLE_WORDS[0];
    const letters = word.word.split('');
    const shuffled = [...letters].sort(() => Math.random() - 0.5);
    setWordPuzzle({
      currentWord: 0,
      letters: [],
      shuffled,
      solved: [],
    });
  }, []);

  // Initialize Picture Quiz
  const initPictureQuiz = useCallback(() => {
    setPictureQuiz({ currentQ: 0, score: 0, answered: false });
  }, []);

  // Initialize Math Challenge
  const initMathChallenge = useCallback(() => {
    setMathChallenge({ currentQ: 0, score: 0, streak: 0, answer: '' });
  }, []);

  // Word Puzzle handlers
  const handleWordPuzzleLetter = (letter: string, index: number) => {
    const newLetters = [...wordPuzzle.letters, letter];
    const newShuffled = wordPuzzle.shuffled.filter((_, i) => i !== index);
    
    if (newLetters.length === WORD_PUZZLE_WORDS[wordPuzzle.currentWord].word.length) {
      const formedWord = newLetters.join('');
      if (formedWord === WORD_PUZZLE_WORDS[wordPuzzle.currentWord].word) {
        // Correct!
        confetti({
          particleCount: 30,
          spread: 50,
          origin: { y: 0.7 },
          colors: ['#F4B7C0', '#9BB5CE', '#B8C5B9']
        });
        
        const newSolved = [...wordPuzzle.solved, true];
        
        if (wordPuzzle.currentWord + 1 >= WORD_PUZZLE_WORDS.length) {
          // All words solved!
          onUnlockAchievement('word-master');
          addToLeaderboard('Word Master', newSolved.length * 100);
        } else {
          // Next word
          const nextWord = WORD_PUZZLE_WORDS[wordPuzzle.currentWord + 1];
          setTimeout(() => {
            setWordPuzzle({
              currentWord: wordPuzzle.currentWord + 1,
              letters: [],
              shuffled: [...nextWord.word.split('')].sort(() => Math.random() - 0.5),
              solved: newSolved,
            });
          }, 1000);
        }
      } else {
        // Wrong - reset
        setTimeout(() => {
          setWordPuzzle(prev => ({
            ...prev,
            letters: [],
            shuffled: [...WORD_PUZZLE_WORDS[prev.currentWord].word.split('')].sort(() => Math.random() - 0.5),
          }));
        }, 500);
      }
    } else {
      setWordPuzzle(prev => ({
        ...prev,
        letters: newLetters,
        shuffled: newShuffled,
      }));
    }
  };

  const handleWordPuzzleBackspace = () => {
    if (wordPuzzle.letters.length > 0) {
      const lastLetter = wordPuzzle.letters[wordPuzzle.letters.length - 1];
      setWordPuzzle(prev => ({
        ...prev,
        letters: prev.letters.slice(0, -1),
        shuffled: [...prev.shuffled, lastLetter],
      }));
    }
  };

  // Picture Quiz handlers
  const handlePictureQuizAnswer = (answer: string) => {
    if (pictureQuiz.answered) return;
    
    const correct = answer === PICTURE_QUIZ_QUESTIONS[pictureQuiz.currentQ].answer;
    
    if (correct) {
      confetti({
        particleCount: 20,
        spread: 40,
        origin: { y: 0.7 },
        colors: ['#F4B7C0', '#9BB5CE']
      });
    }
    
    const newScore = correct ? pictureQuiz.score + 1 : pictureQuiz.score;
    
    setPictureQuiz(prev => ({ ...prev, answered: true }));
    
    setTimeout(() => {
      if (pictureQuiz.currentQ + 1 >= PICTURE_QUIZ_QUESTIONS.length) {
        // Quiz complete
        if (newScore === PICTURE_QUIZ_QUESTIONS.length) {
          onUnlockAchievement('guessing-pro');
        }
        addToLeaderboard('Picture Quiz', newScore * 100);
        setPictureQuiz({ currentQ: 0, score: 0, answered: false });
        setActiveGame(null);
      } else {
        setPictureQuiz(prev => ({
          currentQ: prev.currentQ + 1,
          score: newScore,
          answered: false,
        }));
      }
    }, 1500);
  };

  // Math Challenge handlers
  const handleMathAnswer = () => {
    const userAnswer = parseInt(mathChallenge.answer);
    const correct = userAnswer === MATH_QUESTIONS[mathChallenge.currentQ].answer;
    
    if (correct) {
      confetti({
        particleCount: 20,
        spread: 40,
        origin: { y: 0.7 },
        colors: ['#F4B7C0', '#B8C5B9']
      });
      
      const newStreak = mathChallenge.streak + 1;
      const newScore = mathChallenge.score + 10 + (newStreak * 2);
      
      if (newScore >= 50 && mathChallenge.score < 50) {
        onUnlockAchievement('math-genius');
      }
      
      setTimeout(() => {
        if (mathChallenge.currentQ + 1 >= MATH_QUESTIONS.length) {
          addToLeaderboard('Math Challenge', newScore);
          setMathChallenge({ currentQ: 0, score: 0, streak: 0, answer: '' });
          setActiveGame(null);
        } else {
          setMathChallenge(prev => ({
            currentQ: prev.currentQ + 1,
            score: newScore,
            streak: newStreak,
            answer: '',
          }));
        }
      }, 800);
    } else {
      setMathChallenge(prev => ({
        ...prev,
        streak: 0,
        answer: '',
      }));
    }
  };

  // Leaderboard
  const addToLeaderboard = (game: string, score: number) => {
    const newEntry = { name: 'Deni', score, game };
    setLeaderboard(prev => {
      const updated = [...prev, newEntry].sort((a, b) => b.score - a.score).slice(0, 5);
      return updated;
    });
  };

  // Start game handlers
  const startGame = (game: string) => {
    setActiveGame(game);
    if (game === 'word') initWordPuzzle();
    else if (game === 'picture') initPictureQuiz();
    else if (game === 'math') initMathChallenge();
  };

  return (
    <section
      ref={sectionRef}
      id={id}
      className="min-h-screen bg-paper-warm dark:bg-slate-900 py-20 relative overflow-hidden"
    >
      <div className="max-w-6xl mx-auto px-4 md:px-8">
        {/* Heading */}
        <div ref={headingRef} className="text-center mb-12">
          <div className="inline-flex items-center gap-2 px-4 py-2 bg-scrapbook-blush/20 rounded-full mb-4">
            <FaGamepad className="w-5 h-5 text-scrapbook-blush" />
            <span className="text-sm font-medium text-scrapbook-blush">Fun Corner</span>
          </div>
          <h2 className="handwritten text-5xl md:text-6xl text-scrapbook-charcoal dark:text-slate-100 mb-4">
            Take a Break!
          </h2>
          <p className="text-scrapbook-gray dark:text-slate-400 max-w-md mx-auto">
            Pick a game, challenge yourself, and beat your score!
          </p>
        </div>

        {/* Game Cards */}
        <div ref={gamesRef} className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-12">
          {/* Word Puzzle */}
          <div
            className="game-card paper-card p-6 rounded-[1.5rem] cursor-pointer hover:-translate-y-2 transition-transform"
            onClick={() => startGame('word')}
          >
            <div className="w-14 h-14 bg-scrapbook-dusty rounded-2xl flex items-center justify-center text-white mb-4">
              <FaPuzzlePiece className="w-7 h-7" />
            </div>
            <h3 className="handwritten text-2xl text-scrapbook-charcoal dark:text-slate-100 mb-2">
              Word Puzzle
            </h3>
            <p className="text-sm text-scrapbook-gray dark:text-slate-400">
              Arrange letters to reveal words about digital marketing & data.
            </p>
          </div>

          {/* Picture Quiz */}
          <div
            className="game-card paper-card p-6 rounded-[1.5rem] cursor-pointer hover:-translate-y-2 transition-transform"
            onClick={() => startGame('picture')}
          >
            <div className="w-14 h-14 bg-scrapbook-sage rounded-2xl flex items-center justify-center text-white mb-4">
              <FaImage className="w-7 h-7" />
            </div>
            <h3 className="handwritten text-2xl text-scrapbook-charcoal dark:text-slate-100 mb-2">
              Picture Quiz
            </h3>
            <p className="text-sm text-scrapbook-gray dark:text-slate-400">
              Guess the word from emoji clues!
            </p>
          </div>

          {/* Math Challenge */}
          <div
            className="game-card paper-card p-6 rounded-[1.5rem] cursor-pointer hover:-translate-y-2 transition-transform"
            onClick={() => startGame('math')}
          >
            <div className="w-14 h-14 bg-scrapbook-blush rounded-2xl flex items-center justify-center text-white mb-4">
              <FaCalculator className="w-7 h-7" />
            </div>
            <h3 className="handwritten text-2xl text-scrapbook-charcoal dark:text-slate-100 mb-2">
              Math Challenge
            </h3>
            <p className="text-sm text-scrapbook-gray dark:text-slate-400">
              Quick algebra problems. Build your streak for bonus points!
            </p>
          </div>
        </div>

        {/* Leaderboard */}
        <div ref={leaderboardRef} className="paper-card p-6 rounded-[1.5rem]">
          <div className="flex items-center gap-3 mb-6">
            <FaTrophy className="w-6 h-6 text-yellow-500" />
            <h3 className="handwritten text-2xl text-scrapbook-charcoal dark:text-slate-100">
              Leaderboard
            </h3>
          </div>

          {leaderboard.length > 0 ? (
            <div className="space-y-3">
              {leaderboard.map((entry, i) => (
                <div
                  key={i}
                  className="flex items-center justify-between p-3 bg-paper-cream dark:bg-slate-800 rounded-xl"
                >
                  <div className="flex items-center gap-3">
                    <span className={`w-8 h-8 rounded-full flex items-center justify-center text-sm font-bold ${
                      i === 0 ? 'bg-yellow-400 text-white' :
                      i === 1 ? 'bg-gray-400 text-white' :
                      i === 2 ? 'bg-orange-400 text-white' :
                      'bg-scrapbook-sand text-scrapbook-charcoal'
                    }`}>
                      {i + 1}
                    </span>
                    <span className="text-scrapbook-charcoal dark:text-slate-300">{entry.name}</span>
                  </div>
                  <div className="flex items-center gap-4">
                    <span className="text-sm text-scrapbook-gray">{entry.game}</span>
                    <span className="font-bold text-scrapbook-blush">{entry.score}</span>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <p className="text-center text-scrapbook-gray dark:text-slate-500 py-8">
              Play games to see your scores here!
            </p>
          )}
        </div>
      </div>

      {/* Word Puzzle Modal */}
      {activeGame === 'word' && (
        <div className="fixed inset-0 z-[60] flex items-center justify-center p-4 bg-black/50 backdrop-blur-sm">
          <div className="paper-card max-w-lg w-full p-6 rounded-[1.5rem]">
            <div className="flex items-center justify-between mb-6">
              <h3 className="handwritten text-2xl text-scrapbook-charcoal dark:text-slate-100">
                Word Puzzle
              </h3>
              <button
                onClick={() => setActiveGame(null)}
                className="w-8 h-8 bg-scrapbook-sand/30 rounded-full flex items-center justify-center"
              >
                <span className="text-scrapbook-gray">×</span>
              </button>
            </div>

            <div className="text-center mb-6">
              <p className="text-sm text-scrapbook-gray mb-2">
                Word {wordPuzzle.currentWord + 1} of {WORD_PUZZLE_WORDS.length}
              </p>
              <p className="text-scrapbook-charcoal dark:text-slate-300">
                {WORD_PUZZLE_WORDS[wordPuzzle.currentWord].hint}
              </p>
            </div>

            {/* Answer slots */}
            <div className="flex justify-center gap-2 mb-6">
              {WORD_PUZZLE_WORDS[wordPuzzle.currentWord].word.split('').map((_, i) => (
                <div
                  key={i}
                  className={`w-10 h-12 rounded-lg flex items-center justify-center text-lg font-bold ${
                    i < wordPuzzle.letters.length
                      ? 'bg-scrapbook-blush text-white'
                      : 'bg-paper-cream dark:bg-slate-800 text-scrapbook-gray'
                  }`}
                >
                  {wordPuzzle.letters[i] || ''}
                </div>
              ))}
            </div>

            {/* Letter buttons */}
            <div className="flex flex-wrap justify-center gap-2 mb-4">
              {wordPuzzle.shuffled.map((letter, i) => (
                <button
                  key={i}
                  onClick={() => handleWordPuzzleLetter(letter, i)}
                  className="w-10 h-10 bg-scrapbook-dusty text-white rounded-lg font-bold hover:bg-scrapbook-dusty/80 transition-colors"
                >
                  {letter}
                </button>
              ))}
            </div>

            <button
              onClick={handleWordPuzzleBackspace}
              className="w-full py-3 bg-scrapbook-sand/30 rounded-xl text-scrapbook-gray hover:bg-scrapbook-sand/50 transition-colors"
            >
              ← Backspace
            </button>
          </div>
        </div>
      )}

      {/* Picture Quiz Modal */}
      {activeGame === 'picture' && (
        <div className="fixed inset-0 z-[60] flex items-center justify-center p-4 bg-black/50 backdrop-blur-sm">
          <div className="paper-card max-w-lg w-full p-6 rounded-[1.5rem]">
            <div className="flex items-center justify-between mb-6">
              <h3 className="handwritten text-2xl text-scrapbook-charcoal dark:text-slate-100">
                Picture Quiz
              </h3>
              <button
                onClick={() => setActiveGame(null)}
                className="w-8 h-8 bg-scrapbook-sand/30 rounded-full flex items-center justify-center"
              >
                <span className="text-scrapbook-gray">×</span>
              </button>
            </div>

            <div className="text-center mb-6">
              <p className="text-sm text-scrapbook-gray mb-4">
                Question {pictureQuiz.currentQ + 1} of {PICTURE_QUIZ_QUESTIONS.length}
              </p>
              <div className="text-8xl mb-4">
                {PICTURE_QUIZ_QUESTIONS[pictureQuiz.currentQ].emoji}
              </div>
              <p className="text-scrapbook-gray">
                {PICTURE_QUIZ_QUESTIONS[pictureQuiz.currentQ].hint}
              </p>
            </div>

            {/* Answer options */}
            <div className="grid grid-cols-2 gap-3">
              {['LAPTOP', 'BOOK', 'PHONE', 'SCHOOL', 'CHART'].slice(0, 4).map((option) => (
                <button
                  key={option}
                  onClick={() => handlePictureQuizAnswer(option)}
                  disabled={pictureQuiz.answered}
                  className={`py-3 rounded-xl font-medium transition-colors ${
                    pictureQuiz.answered && option === PICTURE_QUIZ_QUESTIONS[pictureQuiz.currentQ].answer
                      ? 'bg-green-400 text-white'
                      : pictureQuiz.answered
                      ? 'bg-scrapbook-sand/30 text-scrapbook-gray'
                      : 'bg-scrapbook-sage text-white hover:bg-scrapbook-sage/80'
                  }`}
                >
                  {option}
                </button>
              ))}
            </div>

            <div className="mt-4 text-center">
              <p className="text-sm text-scrapbook-gray">
                Score: {pictureQuiz.score}
              </p>
            </div>
          </div>
        </div>
      )}

      {/* Math Challenge Modal */}
      {activeGame === 'math' && (
        <div className="fixed inset-0 z-[60] flex items-center justify-center p-4 bg-black/50 backdrop-blur-sm">
          <div className="paper-card max-w-lg w-full p-6 rounded-[1.5rem]">
            <div className="flex items-center justify-between mb-6">
              <h3 className="handwritten text-2xl text-scrapbook-charcoal dark:text-slate-100">
                Math Challenge
              </h3>
              <button
                onClick={() => setActiveGame(null)}
                className="w-8 h-8 bg-scrapbook-sand/30 rounded-full flex items-center justify-center"
              >
                <span className="text-scrapbook-gray">×</span>
              </button>
            </div>

            <div className="text-center mb-6">
              <p className="text-sm text-scrapbook-gray mb-4">
                Question {mathChallenge.currentQ + 1} of {MATH_QUESTIONS.length}
              </p>
              <p className="text-3xl font-display text-scrapbook-charcoal dark:text-slate-100 mb-2">
                {MATH_QUESTIONS[mathChallenge.currentQ].question}
              </p>
              <p className="text-sm text-scrapbook-blush">
                Streak: {mathChallenge.streak} 🔥
              </p>
            </div>

            {/* Answer input */}
            <div className="flex gap-3 mb-4">
              <input
                type="number"
                value={mathChallenge.answer}
                onChange={(e) => setMathChallenge(prev => ({ ...prev, answer: e.target.value }))}
                onKeyPress={(e) => e.key === 'Enter' && handleMathAnswer()}
                placeholder="Your answer"
                className="flex-1 input-scrapbook text-center text-xl"
              />
              <button
                onClick={handleMathAnswer}
                className="btn-scrapbook px-6"
              >
                <FaArrowRight />
              </button>
            </div>

            <div className="text-center">
              <p className="text-sm text-scrapbook-gray">
                Score: {mathChallenge.score}
              </p>
            </div>
          </div>
        </div>
      )}
    </section>
  );
}
