import { useEffect, useRef, useState } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { FaGraduationCap, FaBriefcase, FaUsers, FaHeart, FaStar, FaChevronRight, FaTimes } from 'react-icons/fa';

gsap.registerPlugin(ScrollTrigger);

interface GoalsSectionProps {
  id: string;
}

const goals = [
  {
    id: 'study',
    title: 'Belajar Digital Marketing & Data Science',
    icon: FaGraduationCap,
    description: 'Melanjutkan pendidikan di bidang Digital Marketing dan Data Science untuk membangun fondasi yang kuat untuk karir saya.',
    skills: ['Marketing Strategy', 'Data Analysis', 'Python Programming', 'SQL'],
    color: 'bg-scrapbook-dusty',
  },
  {
    id: 'projects',
    title: 'Membangun Proyek Nyata',
    icon: FaBriefcase,
    description: 'Mengerjakan kampanye dan proyek analisis data dunia nyata untuk mendapatkan pengalaman praktis.',
    skills: ['Campaign Management', 'Analytics Tools', 'A/B Testing', 'Reporting'],
    color: 'bg-scrapbook-sage',
  },
  {
    id: 'growth',
    title: 'Berkembang sebagai Team Player',
    icon: FaUsers,
    description: 'Mengembangkan soft skills dan belajar berkolaborasi secara efektif dalam tim yang beragam.',
    skills: ['Communication', 'Leadership', 'Problem Solving', 'Adaptability'],
    color: 'bg-scrapbook-blush',
  },
];

export default function GoalsSection({ id }: GoalsSectionProps) {
  const sectionRef = useRef<HTMLDivElement>(null);
  const leftCardRef = useRef<HTMLDivElement>(null);
  const rightCardRef = useRef<HTMLDivElement>(null);
  const badgeRef = useRef<HTMLDivElement>(null);
  const stickersRef = useRef<HTMLDivElement>(null);
  const [selectedGoal, setSelectedGoal] = useState<string | null>(null);

  useEffect(() => {
    const section = sectionRef.current;
    const leftCard = leftCardRef.current;
    const rightCard = rightCardRef.current;
    const badge = badgeRef.current;
    const stickers = stickersRef.current;

    if (!section || !leftCard || !rightCard || !badge || !stickers) return;

    const ctx = gsap.context(() => {
      const scrollTl = gsap.timeline({
        scrollTrigger: {
          trigger: section,
          start: 'top top',
          end: '+=130%',
          pin: true,
          scrub: 0.6,
        }
      });

      // Left card entrance (0% - 30%)
      scrollTl.fromTo(leftCard,
        { x: '-60vw', rotate: -6, opacity: 0 },
        { x: 0, rotate: -1, opacity: 1, ease: 'none' },
        0
      );

      // Text elements in left card
      const heading = leftCard.querySelector('.section-heading');
      const paragraphs = leftCard.querySelectorAll('.goal-text');
      const goalItems = leftCard.querySelectorAll('.goal-item');

      scrollTl.fromTo(heading,
        { y: 24, opacity: 0 },
        { y: 0, opacity: 1, ease: 'none' },
        0.1
      );

      paragraphs.forEach((p, i) => {
        scrollTl.fromTo(p,
          { y: 18, opacity: 0 },
          { y: 0, opacity: 1, ease: 'none' },
          0.15 + i * 0.05
        );
      });

      goalItems.forEach((item, i) => {
        scrollTl.fromTo(item,
          { x: -20, opacity: 0 },
          { x: 0, opacity: 1, ease: 'none' },
          0.2 + i * 0.04
        );
      });

      // Right card entrance (0% - 30%)
      scrollTl.fromTo(rightCard,
        { x: '60vw', rotate: 6, opacity: 0 },
        { x: 0, rotate: 1.5, opacity: 1, ease: 'none' },
        0
      );

      // Photos in right card
      const photos = rightCard.querySelectorAll('.goal-photo');
      photos.forEach((photo, i) => {
        scrollTl.fromTo(photo,
          { y: 30, rotate: -5 + i * 5, opacity: 0 },
          { y: 0, rotate: -2 + i * 2, opacity: 1, ease: 'none' },
          0.1 + i * 0.05
        );
      });

      // Badge entrance (15% - 35%)
      scrollTl.fromTo(badge,
        { scale: 0, rotate: -12, opacity: 0 },
        { scale: 1, rotate: 0, opacity: 1, ease: 'back.out(1.6)' },
        0.15
      );

      // Stickers entrance
      const stickerElements = stickers.querySelectorAll('.sticker');
      stickerElements.forEach((sticker, i) => {
        scrollTl.fromTo(sticker,
          { scale: 0, opacity: 0 },
          { scale: 1, opacity: 1, ease: 'back.out(1.8)' },
          0.1 + i * 0.05
        );
      });

      // Exit animations (70% - 100%)
      scrollTl.fromTo(leftCard,
        { x: 0, opacity: 1 },
        { x: '-35vw', opacity: 0, ease: 'power2.in' },
        0.7
      );

      scrollTl.fromTo(rightCard,
        { x: 0, opacity: 1 },
        { x: '35vw', opacity: 0, ease: 'power2.in' },
        0.7
      );

      scrollTl.fromTo(badge,
        { y: 0, opacity: 1 },
        { y: '25vh', opacity: 0, ease: 'power2.in' },
        0.7
      );

      scrollTl.fromTo(stickerElements,
        { opacity: 1 },
        { opacity: 0, ease: 'power2.in', stagger: 0.02 },
        0.75
      );

    }, section);

    return () => ctx.revert();
  }, []);

  const selectedGoalData = goals.find(g => g.id === selectedGoal);

  return (
    <section
      ref={sectionRef}
      id={id}
      className="section-pinned bg-paper-warm dark:bg-slate-900 flex items-center justify-center relative overflow-hidden"
    >
      <div className="w-full max-w-7xl mx-auto px-4 md:px-8 grid grid-cols-1 lg:grid-cols-2 gap-8 items-center">
        {/* Left Card - Goals List */}
        <div
          ref={leftCardRef}
          className="paper-card p-6 md:p-8 rounded-[2rem] relative"
          style={{ transform: 'rotate(-1deg)' }}
        >
          {/* Washi tape */}
          <div className="absolute -top-3 left-8 w-24 h-6 bg-scrapbook-blush/80 rotate-1" />

          <h2 className="section-heading handwritten text-4xl md:text-5xl text-scrapbook-charcoal dark:text-slate-100 mb-4 doodle-line inline-block">
            Tujuan Masa Depan
          </h2>

          <p className="goal-text text-base text-scrapbook-gray dark:text-slate-400 mb-6 leading-relaxed">
            Saya ingin bekerja di tempat kreativitas bertemu logika—membantu brand bercerita dengan dukungan data.
          </p>

          {/* Career Goals */}
          <div className="space-y-3">
            {goals.map((goal) => (
              <button
                key={goal.id}
                onClick={() => setSelectedGoal(goal.id)}
                className="goal-item w-full flex items-center gap-4 p-4 bg-paper-cream dark:bg-slate-800 rounded-xl hover:shadow-md transition-all duration-300 group text-left"
              >
                <div className={`w-12 h-12 ${goal.color} rounded-full flex items-center justify-center text-white flex-shrink-0 group-hover:scale-110 transition-transform`}>
                  <goal.icon className="w-5 h-5" />
                </div>
                <div className="flex-1">
                  <h4 className="font-medium text-scrapbook-charcoal dark:text-slate-200 group-hover:text-scrapbook-blush transition-colors">
                    {goal.title}
                  </h4>
                </div>
                <FaChevronRight className="w-4 h-4 text-scrapbook-gray group-hover:translate-x-1 transition-transform" />
              </button>
            ))}
          </div>
        </div>

        {/* Right Card - Photos */}
        <div
          ref={rightCardRef}
          className="paper-card p-6 md:p-8 rounded-[2rem] relative min-h-[400px]"
          style={{ transform: 'rotate(1.5deg)' }}
        >
          <h3 className="handwritten text-2xl text-scrapbook-charcoal dark:text-slate-100 mb-6 text-center">
            Papan Visi
          </h3>

          {/* Photo Stack */}
          <div className="relative h-[280px] md:h-[320px]">
            <div
              className="goal-photo absolute top-0 left-0 w-44 md:w-52 polaroid"
              style={{ transform: 'rotate(-2deg)' }}
            >
              <img
                src="/images/goals_photo_01.jpg"
                alt="Workspace"
                className="w-full h-40 md:h-48 object-cover"
              />
              <p className="text-center handwritten text-sm text-scrapbook-gray mt-2">Workspace impianku</p>
            </div>

            <div
              className="goal-photo absolute top-12 left-16 md:left-24 w-44 md:w-52 polaroid"
              style={{ transform: 'rotate(2deg)' }}
            >
              <img
                src="/images/goals_photo_02.jpg"
                alt="Vision Board"
                className="w-full h-40 md:h-48 object-cover"
              />
              <p className="text-center handwritten text-sm text-scrapbook-gray mt-2">Vision board</p>
            </div>
          </div>
        </div>
      </div>

      {/* Motivational Badge */}
      <div
        ref={badgeRef}
        className="absolute bottom-[10%] left-1/2 -translate-x-1/2"
      >
        <div className="w-32 h-32 md:w-40 md:h-40 bg-gradient-to-br from-scrapbook-blush to-scrapbook-peach rounded-full flex items-center justify-center shadow-glow animate-pulse-soft">
          <p className="handwritten text-lg md:text-xl text-white text-center px-4 leading-tight">
            Bermimpi besar.<br />Mulai kecil.<br />Tetap konsisten.
          </p>
        </div>
      </div>

      {/* Decorative Stickers */}
      <div ref={stickersRef} className="absolute inset-0 pointer-events-none">
        <div className="sticker absolute top-[15%] right-[10%] w-10 h-10 bg-scrapbook-blush rounded-full flex items-center justify-center text-white animate-float">
          <FaHeart className="w-4 h-4" />
        </div>
        <div className="sticker absolute bottom-[25%] left-[5%] w-12 h-12 bg-yellow-300 rounded-full flex items-center justify-center text-white animate-float" style={{ animationDelay: '0.5s' }}>
          <FaStar className="w-5 h-5" />
        </div>
      </div>

      {/* Goal Detail Modal */}
      {selectedGoalData && (
        <div className="fixed inset-0 z-[60] flex items-center justify-center p-4 bg-black/50 backdrop-blur-sm">
          <div className="paper-card max-w-md w-full p-6 rounded-[1.5rem] animate-pop-in">
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-3">
                <div className={`w-12 h-12 ${selectedGoalData.color} rounded-full flex items-center justify-center text-white`}>
                  <selectedGoalData.icon className="w-5 h-5" />
                </div>
                <h3 className="handwritten text-2xl text-scrapbook-charcoal dark:text-slate-100">
                  {selectedGoalData.title}
                </h3>
              </div>
              <button
                onClick={() => setSelectedGoal(null)}
                className="w-8 h-8 bg-scrapbook-sand/30 rounded-full flex items-center justify-center hover:bg-scrapbook-sand/50 transition-colors"
              >
                <FaTimes className="w-4 h-4 text-scrapbook-gray" />
              </button>
            </div>

            <p className="text-scrapbook-gray dark:text-slate-400 mb-6 leading-relaxed">
              {selectedGoalData.description}
            </p>

            <div>
              <p className="text-sm font-medium text-scrapbook-charcoal dark:text-slate-300 mb-3">
                Skill yang Perlu Dikembangkan:
              </p>
              <div className="flex flex-wrap gap-2">
                {selectedGoalData.skills.map((skill, i) => (
                  <span
                    key={i}
                    className="px-3 py-1 bg-paper-cream dark:bg-slate-800 rounded-full text-sm text-scrapbook-gray dark:text-slate-400"
                  >
                    {skill}
                  </span>
                ))}
              </div>
            </div>
          </div>
        </div>
      )}
    </section>
  );
}
