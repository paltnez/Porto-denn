import { FaMoon, FaSun, FaMusic, FaPause } from 'react-icons/fa';

interface FloatingControlsProps {
  isDark: boolean;
  onToggleDark: () => void;
  isPlaying: boolean;
  onToggleAudio: () => void;
}

export default function FloatingControls({ 
  isDark, 
  onToggleDark, 
  isPlaying, 
  onToggleAudio 
}: FloatingControlsProps) {
  return (
    <div className="fixed bottom-6 right-6 z-50 flex flex-col gap-3">
      {/* Music Toggle */}
      <button
        onClick={onToggleAudio}
        className={`relative w-12 h-12 rounded-full paper-card flex items-center justify-center transition-all duration-300 hover:scale-110 group ${
          isPlaying ? 'shadow-glow' : ''
        }`}
        title={isPlaying ? 'Pause Music' : 'Play Music'}
      >
        {/* Vinyl Animation */}
        {isPlaying && (
          <div className="absolute inset-0 rounded-full border-2 border-scrapbook-blush animate-spin-slow" />
        )}
        <div className={`relative ${isPlaying ? 'animate-pulse-soft' : ''}`}>
          {isPlaying ? (
            <FaPause className="w-4 h-4 text-scrapbook-blush" />
          ) : (
            <FaMusic className="w-4 h-4 text-scrapbook-gray group-hover:text-scrapbook-blush transition-colors" />
          )}
        </div>
      </button>

      {/* Dark Mode Toggle */}
      <button
        onClick={onToggleDark}
        className="w-12 h-12 rounded-full paper-card flex items-center justify-center transition-all duration-300 hover:scale-110 group"
        title={isDark ? 'Light Mode' : 'Dark Mode'}
      >
        {isDark ? (
          <FaSun className="w-5 h-5 text-yellow-400 group-hover:rotate-180 transition-transform duration-500" />
        ) : (
          <FaMoon className="w-5 h-5 text-scrapbook-dusty group-hover:rotate-12 transition-transform" />
        )}
      </button>
    </div>
  );
}
