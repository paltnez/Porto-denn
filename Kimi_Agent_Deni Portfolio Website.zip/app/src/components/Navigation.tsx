import { useState, useEffect } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { FaBookOpen } from 'react-icons/fa';

gsap.registerPlugin(ScrollTrigger);

interface NavigationProps {
  onNavigate: (sectionId: string) => void;
}

const navItems = [
  { id: 'about', label: 'About' },
  { id: 'interests', label: 'Interests' },
  { id: 'goals', label: 'Goals' },
  { id: 'games', label: 'Games' },
  { id: 'contact', label: 'Contact' },
];

export default function Navigation({ onNavigate }: NavigationProps) {
  const [isVisible, setIsVisible] = useState(false);
  const [activeSection, setActiveSection] = useState('');

  useEffect(() => {
    // Show navigation after scrolling past hero
    ScrollTrigger.create({
      trigger: '#about',
      start: 'top 80%',
      onEnter: () => setIsVisible(true),
      onLeaveBack: () => setIsVisible(false),
    });

    // Track active section
    const sections = ['about', 'interests', 'goals', 'games', 'contact'];
    sections.forEach(section => {
      ScrollTrigger.create({
        trigger: `#${section}`,
        start: 'top center',
        end: 'bottom center',
        onEnter: () => setActiveSection(section),
        onEnterBack: () => setActiveSection(section),
      });
    });

    return () => {
      ScrollTrigger.getAll().forEach(st => {
        if (st.vars.trigger && ['#about', '#interests', '#goals', '#games', '#contact'].includes(st.vars.trigger as string)) {
          st.kill();
        }
      });
    };
  }, []);

  const handleClick = (id: string) => {
    onNavigate(id);
  };

  return (
    <nav
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-500 ${
        isVisible ? 'translate-y-0 opacity-100' : '-translate-y-full opacity-0'
      }`}
    >
      <div className="mx-4 mt-4">
        <div className="paper-card px-6 py-3 flex items-center justify-between max-w-6xl mx-auto">
          {/* Logo */}
          <button
            onClick={() => handleClick('hero')}
            className="flex items-center gap-2 group"
          >
            <FaBookOpen className="w-5 h-5 text-scrapbook-blush group-hover:scale-110 transition-transform" />
            <span className="handwritten text-xl text-scrapbook-charcoal dark:text-slate-100">
              Deni's Journal
            </span>
          </button>

          {/* Nav Links */}
          <div className="hidden md:flex items-center gap-1">
            {navItems.map(item => (
              <button
                key={item.id}
                onClick={() => handleClick(item.id)}
                className={`px-4 py-2 rounded-lg text-sm font-medium transition-all duration-300 ${
                  activeSection === item.id
                    ? 'bg-scrapbook-blush/30 text-scrapbook-charcoal dark:text-slate-100'
                    : 'text-scrapbook-gray hover:text-scrapbook-charcoal dark:text-slate-400 dark:hover:text-slate-100'
                }`}
              >
                {item.label}
              </button>
            ))}
          </div>

          {/* Mobile Menu Button */}
          <button className="md:hidden p-2">
            <div className="w-5 h-0.5 bg-scrapbook-charcoal mb-1" />
            <div className="w-5 h-0.5 bg-scrapbook-charcoal mb-1" />
            <div className="w-5 h-0.5 bg-scrapbook-charcoal" />
          </button>
        </div>
      </div>
    </nav>
  );
}
