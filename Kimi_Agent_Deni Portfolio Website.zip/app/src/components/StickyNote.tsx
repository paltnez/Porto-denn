import { useState, useEffect } from 'react';
import { FaTimes } from 'react-icons/fa';

interface StickyNoteProps {
  color: string;
  position: 'left' | 'right';
  fact: string;
  onClose: () => void;
}

export default function StickyNote({ color, position, fact, onClose }: StickyNoteProps) {
  const [isOpen, setIsOpen] = useState(true);
  const [isVisible, setIsVisible] = useState(true);

  // Auto close after 8 seconds to give more time to read
  useEffect(() => {
    const timer = setTimeout(() => {
      handleClose();
    }, 8000);
    return () => clearTimeout(timer);
  }, []);

  const handleClose = () => {
    setIsOpen(false);
    setTimeout(() => {
      setIsVisible(false);
      onClose();
    }, 300);
  };

  if (!isVisible) return null;

  return (
    <div
      className={`fixed ${position === 'left' ? 'left-4' : 'right-4'} top-24 z-40 transition-all duration-300 ${
        isOpen ? 'opacity-100 translate-y-0' : 'opacity-0 -translate-y-4'
      }`}
      style={{ transform: position === 'left' ? 'rotate(-3deg)' : 'rotate(3deg)' }}
    >
      <div className={`${color} p-4 rounded-sm shadow-lg max-w-[200px] relative`}>
        {/* Tape */}
        <div className="absolute -top-3 left-1/2 -translate-x-1/2 w-16 h-6 bg-white/40" />
        
        {/* Close Button */}
        <button
          onClick={handleClose}
          className="absolute -top-2 -right-2 w-6 h-6 bg-scrapbook-charcoal text-white rounded-full flex items-center justify-center hover:bg-red-400 transition-colors"
        >
          <FaTimes className="w-3 h-3" />
        </button>

        {/* Content */}
        <p className="text-sm font-medium text-scrapbook-charcoal leading-relaxed">
          <span className="handwritten text-lg block mb-1">Fakta Menarik!</span>
          {fact}
        </p>

        {/* Folded corner */}
        <div 
          className="absolute bottom-0 right-0 w-6 h-6"
          style={{
            background: 'linear-gradient(135deg, transparent 50%, rgba(0,0,0,0.1) 50%)',
          }}
        />
      </div>
    </div>
  );
}
