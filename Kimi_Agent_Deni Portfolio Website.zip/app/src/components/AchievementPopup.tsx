import { useEffect, useRef } from 'react';
import { gsap } from 'gsap';
import confetti from 'canvas-confetti';
import { FaTrophy } from 'react-icons/fa';
import type { Achievement } from '../hooks/useAchievements';

interface AchievementPopupProps {
  achievement: Achievement;
  onClose: () => void;
}

export default function AchievementPopup({ achievement, onClose }: AchievementPopupProps) {
  const popupRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    // Trigger confetti
    const duration = 2000;
    const end = Date.now() + duration;

    const frame = () => {
      confetti({
        particleCount: 5,
        angle: 60,
        spread: 55,
        origin: { x: 0 },
        colors: ['#F4B7C0', '#9BB5CE', '#B8C5B9', '#F4D5C7']
      });
      confetti({
        particleCount: 5,
        angle: 120,
        spread: 55,
        origin: { x: 1 },
        colors: ['#F4B7C0', '#9BB5CE', '#B8C5B9', '#F4D5C7']
      });

      if (Date.now() < end) {
        requestAnimationFrame(frame);
      }
    };
    frame();

    // Animate popup
    if (popupRef.current) {
      gsap.fromTo(popupRef.current,
        { scale: 0, opacity: 0, y: 50 },
        { scale: 1, opacity: 1, y: 0, duration: 0.5, ease: 'back.out(1.7)' }
      );
    }

    // Auto close after 4 seconds
    const timer = setTimeout(() => {
      if (popupRef.current) {
        gsap.to(popupRef.current, {
          scale: 0,
          opacity: 0,
          y: 50,
          duration: 0.3,
          onComplete: onClose
        });
      }
    }, 4000);

    return () => clearTimeout(timer);
  }, [onClose]);

  return (
    <div className="fixed inset-0 flex items-center justify-center z-[100] pointer-events-none">
      <div
        ref={popupRef}
        className="paper-card p-6 max-w-sm mx-4 text-center pointer-events-auto"
      >
        <div className="w-16 h-16 bg-gradient-to-br from-yellow-300 to-orange-400 rounded-full flex items-center justify-center mx-auto mb-4 animate-bounce-soft">
          <FaTrophy className="w-8 h-8 text-white" />
        </div>
        
        <h3 className="handwritten text-2xl text-scrapbook-charcoal dark:text-slate-100 mb-2">
          Achievement Unlocked!
        </h3>
        
        <div className="text-4xl mb-2">{achievement.icon}</div>
        
        <h4 className="font-display font-bold text-lg text-scrapbook-charcoal dark:text-slate-100 mb-1">
          {achievement.name}
        </h4>
        
        <p className="text-sm text-scrapbook-gray dark:text-slate-400">
          {achievement.description}
        </p>
      </div>
    </div>
  );
}
