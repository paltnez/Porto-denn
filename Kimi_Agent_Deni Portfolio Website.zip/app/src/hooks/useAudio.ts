import { useState, useEffect, useRef } from 'react';

export default function useAudio() {
  const [isPlaying, setIsPlaying] = useState(() => {
    if (typeof window !== 'undefined') {
      const saved = localStorage.getItem('musicPlaying');
      return saved ? JSON.parse(saved) : false;
    }
    return false;
  });
  
  const audioRef = useRef<HTMLAudioElement | null>(null);

  useEffect(() => {
    // Create audio element with local music file
    audioRef.current = new Audio('/music/lesung-pipi.mp3');
    audioRef.current.loop = true;
    audioRef.current.volume = 0.4;

    return () => {
      if (audioRef.current) {
        audioRef.current.pause();
        audioRef.current = null;
      }
    };
  }, []);

  useEffect(() => {
    localStorage.setItem('musicPlaying', JSON.stringify(isPlaying));
    
    if (audioRef.current) {
      if (isPlaying) {
        audioRef.current.play().catch(() => {
          // Auto-play blocked, user needs to interact first
          setIsPlaying(false);
        });
      } else {
        audioRef.current.pause();
      }
    }
  }, [isPlaying]);

  const toggleAudio = () => setIsPlaying((prev: boolean) => !prev);

  return { isPlaying, toggleAudio };
}
