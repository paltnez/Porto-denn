import { useState, useEffect, useCallback } from 'react';

export interface Achievement {
  id: string;
  name: string;
  description: string;
  icon: string;
}

const ACHIEVEMENTS: Achievement[] = [
  { id: 'word-master', name: 'Word Master', description: 'Berhasil menyelesaikan game susun kata!', icon: '📚' },
  { id: 'math-genius', name: 'Math Genius', description: 'Berhasil menjawab 5 soal matematika dengan benar!', icon: '🔢' },
  { id: 'guessing-pro', name: 'Guessing Pro', description: 'Berhasil menebak semua gambar dengan benar!', icon: '🎯' },
  { id: 'first-visit', name: 'First Visit', description: 'Selamat datang di jurnal Deni!', icon: '🎉' },
];

export default function useAchievements() {
  const [unlocked, setUnlocked] = useState<string[]>(() => {
    if (typeof window !== 'undefined') {
      const saved = localStorage.getItem('achievements');
      return saved ? JSON.parse(saved) : [];
    }
    return [];
  });
  
  const [showAchievement, setShowAchievement] = useState<Achievement | null>(null);

  useEffect(() => {
    localStorage.setItem('achievements', JSON.stringify(unlocked));
  }, [unlocked]);

  // Unlock first visit on mount
  useEffect(() => {
    const timer = setTimeout(() => {
      if (!unlocked.includes('first-visit')) {
        unlockAchievement('first-visit');
      }
    }, 2000);
    return () => clearTimeout(timer);
  }, []);

  const unlockAchievement = useCallback((id: string) => {
    if (!unlocked.includes(id)) {
      const achievement = ACHIEVEMENTS.find(a => a.id === id);
      if (achievement) {
        setUnlocked(prev => [...prev, id]);
        setShowAchievement(achievement);
      }
    }
  }, [unlocked]);

  const clearAchievement = useCallback(() => {
    setShowAchievement(null);
  }, []);

  return {
    achievements: unlocked,
    showAchievement,
    unlockAchievement,
    clearAchievement,
    allAchievements: ACHIEVEMENTS
  };
}
